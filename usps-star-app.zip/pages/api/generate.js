import { callClaude } from "../../lib/claude";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const { requirementText, profile, budget } = req.body || {};
  if (!requirementText || !profile) {
    return res.status(400).json({ error: "requirementText and profile are required" });
  }

  const target = Math.max(300, Math.floor((budget || 1000) * 0.9));
  const prompt = `You are helping a USPS employee draft a response to one job qualification requirement for an internal eCareer application. Using the requirement below and the candidate's background information, write a STAR-format response (Situation, Task, Action, Result) as flowing narrative paragraphs. Do NOT include visible "Situation:"/"Task:"/"Action:"/"Result:" subheadings — write it as connected prose.

Draw only on details actually present in the candidate's background information below. Do not invent specifics (names, numbers, dates) that were not provided. Use accurate USPS terminology where the candidate has supplied it.

Requirement: ${requirementText}

Candidate background:
- Current position: ${profile.currentPosition || ""}
- Years in role: ${profile.yearsInRole || ""}
- Key projects/initiatives: ${profile.projects || ""}
- Programs/tools/systems used: ${profile.programsTools || ""}
- Measurable outcomes: ${profile.outcomes || ""}
- Leadership/supervisory scope: ${profile.leadershipScope || ""}
- Training/certifications: ${profile.training || ""}

Target length: approximately ${target} characters. Stay at or under this length. Output only the response text, nothing else.`;

  try {
    const text = await callClaude(prompt, 700);
    return res.status(200).json({ text: text.trim() });
  } catch (e) {
    return res.status(500).json({ error: e.message || "Generation failed" });
  }
}
