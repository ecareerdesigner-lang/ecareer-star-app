import Stripe from "stripe";
import { FLAT_FEE_CENTS, CURRENCY, applyPromo } from "../../lib/config";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const secretKey = process.env.STRIPE_SECRET_KEY;
  const { jobTitle, promoCode } = req.body || {};
  const { finalCents } = applyPromo(promoCode);

  if (!secretKey) {
    // No Stripe key configured — return a message rather than silently
    // pretending to charge. Wire up STRIPE_SECRET_KEY in .env.local to
    // enable real checkout.
    return res.status(500).json({
      error: "STRIPE_SECRET_KEY is not set. Add it to .env.local to enable real payments (see README).",
    });
  }

  const stripe = new Stripe(secretKey);

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [
        {
          price_data: {
            currency: CURRENCY,
            product_data: {
              name: `eCareer application assistance — ${jobTitle || "job title"}`,
            },
            unit_amount: finalCents,
          },
          quantity: 1,
        },
      ],
      success_url: `${req.headers.origin}/?paid=1&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.origin}/?paid=0`,
    });
    return res.status(200).json({ url: session.url });
  } catch (e) {
    return res.status(500).json({ error: e.message || "Could not create checkout session" });
  }
}

// NOTE: For production, also add a Stripe webhook route
// (pages/api/webhook.js) listening for `checkout.session.completed` to mark
// the application's payment_status as paid server-side. Relying on the
// success_url redirect alone is fine for a v1 but is spoofable by a user
// manually visiting that URL.
