import { callClaude } from "../../lib/claude";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const { jobTitle, profile } = req.body || {};
  if (!jobTitle || !profile) {
    return res.status(400).json({ error: "jobTitle and profile are required" });
  }

  const prompt = `Based on the job title "${jobTitle}" and the candidate's background below, write a brief summary (3-5 sentences) of special skills, professional associations, certifications, or affiliations relevant to this role. Only include items grounded in the candidate's actual background below — do not fabricate credentials or memberships. Output only the summary text.

Candidate background:
- Current position: ${profile.currentPosition || ""}
- Programs/tools/systems used: ${profile.programsTools || ""}
- Training/certifications: ${profile.training || ""}
- Measurable outcomes: ${profile.outcomes || ""}`;

  try {
    const text = await callClaude(prompt, 400);
    return res.status(200).json({ text: text.trim() });
  } catch (e) {
    return res.status(500).json({ error: e.message || "Summary generation failed" });
  }
}
