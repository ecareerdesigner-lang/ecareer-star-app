import { callClaude } from "../../lib/claude";
import { extractJsonArray } from "../../lib/parse";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }
  const { pastedText } = req.body || {};
  if (!pastedText || !pastedText.trim()) {
    return res.status(400).json({ error: "pastedText is required" });
  }

  const prompt = `You will be given raw text copied from a USPS eCareer job posting. Extract only the distinct Qualifications/Requirements/KSAs as a numbered list. Do not include unrelated posting content (pay grade, location, application instructions). Output strictly as a JSON array of strings, one requirement per item, in the order they appear. Do not include any preamble, explanation, or markdown formatting — JSON array only.

Posting text:
"""
${pastedText}
"""`;

  try {
    const raw = await callClaude(prompt, 1200);
    const parsed = extractJsonArray(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return res.status(422).json({ error: "Could not find distinct requirements in that text." });
    }
    return res.status(200).json({ items: parsed.filter((x) => typeof x === "string" && x.trim()) });
  } catch (e) {
    return res.status(500).json({ error: e.message || "Extraction failed" });
  }
}
