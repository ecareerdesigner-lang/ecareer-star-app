import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/router";
import {
  Search, DollarSign, Sparkles, Copy, Download,
  RefreshCw, ArrowRight, ArrowLeft, CheckCircle2, AlertTriangle,
  Plus, Trash2,
} from "lucide-react";
import { APP_NAME, APP_TAGLINE, FLAT_FEE_CENTS, TOTAL_CHARACTER_BUDGET } from "../lib/config";
import { JOB_LIBRARY, splitNumberedRequirements } from "../lib/parse";

const STEPS = ["title", "requirements", "payment", "intake", "generate", "review"];

async function postJSON(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request to ${url} failed (${res.status})`);
  return data;
}

export default function Home() {
  const router = useRouter();
  const [step, setStep] = useState("title");
  const [jobTitle, setJobTitle] = useState("");
  const [libraryMatch, setLibraryMatch] = useState(null);
  const [searched, setSearched] = useState(false);
  const [pastedText, setPastedText] = useState("");
  const [requirements, setRequirements] = useState([]);
  const [extracting, setExtracting] = useState(false);
  const [paid, setPaid] = useState(false);
  const [paying, setPaying] = useState(false);
  const [promoCode, setPromoCode] = useState("");

  const [profile, setProfile] = useState({
    currentPosition: "", yearsInRole: "", projects: "",
    programsTools: "", outcomes: "", leadershipScope: "", training: "",
  });

  const [skillsSummary, setSkillsSummary] = useState("");
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [genError, setGenError] = useState("");

  // Handle return from Stripe Checkout (?paid=1). For production, verify
  // this server-side via a webhook rather than trusting the redirect alone.
  useEffect(() => {
    if (router.query.paid === "1") {
      setPaid(true);
      setStep((s) => (s === "payment" || s === "title" ? "intake" : s));
    }
  }, [router.query.paid]);

  const stepIndex = STEPS.indexOf(step);
  const totalUsed = useMemo(
    () => requirements.reduce((sum, r) => sum + (r.response?.length || 0), 0),
    [requirements]
  );
  const overBudget = totalUsed > TOTAL_CHARACTER_BUDGET;

  function seedRequirements(list) {
    const even = Math.floor(TOTAL_CHARACTER_BUDGET / list.length);
    setRequirements(
      list.map((text, i) => ({
        id: `req-${i}-${Date.now()}`,
        number: i + 1,
        text,
        budget: even,
        response: "",
        generating: false,
      }))
    );
  }

  function handleSearch() {
    const key = jobTitle.trim().toLowerCase();
    const match = JOB_LIBRARY[key] || null;
    setLibraryMatch(match);
    setSearched(true);
    if (match) seedRequirements(match.requirements);
  }

  async function handleExtractFromPaste() {
    if (!pastedText.trim()) return;
    setExtracting(true);
    setGenError("");

    const localItems = splitNumberedRequirements(pastedText);
    if (localItems.length >= 2) {
      seedRequirements(localItems);
      setStep("requirements");
      setExtracting(false);
      return;
    }

    try {
      const { items } = await postJSON("/api/extract", { pastedText });
      if (items && items.length > 0) {
        seedRequirements(items);
        setStep("requirements");
      } else {
        setGenError("Couldn't find distinct requirements in that text. Try pasting just the Qualifications section.");
      }
    } catch (e) {
      setGenError(`Extraction failed: ${e.message}`);
    } finally {
      setExtracting(false);
    }
  }

  async function handlePay() {
    setPaying(true);
    setGenError("");
    try {
      const { url } = await postJSON("/api/checkout", { jobTitle, promoCode });
      window.location.href = url; // redirect to Stripe Checkout
    } catch (e) {
      setGenError(`Payment setup failed: ${e.message}`);
      setPaying(false);
    }
  }

  function updateBudget(id, value) {
    setRequirements((prev) => prev.map((r) => (r.id === id ? { ...r, budget: Math.max(0, value) } : r)));
  }

  async function generateOne(req) {
    setRequirements((prev) => prev.map((r) => (r.id === req.id ? { ...r, generating: true } : r)));
    try {
      const { text } = await postJSON("/api/generate", {
        requirementText: req.text, profile, budget: req.budget,
      });
      setRequirements((prev) => prev.map((r) => (r.id === req.id ? { ...r, response: text, generating: false } : r)));
    } catch (e) {
      setRequirements((prev) => prev.map((r) => (r.id === req.id ? { ...r, generating: false } : r)));
      setGenError(`Failed to generate a response for requirement ${req.number}: ${e.message}`);
    }
  }

  async function generateAll() {
    setGenError("");
    setStep("generate");
    for (const req of requirements) {
      await generateOne(req);
    }
    await generateSkillsSummary();
    setStep("review");
  }

  async function generateSkillsSummary() {
    setSummaryLoading(true);
    try {
      const { text } = await postJSON("/api/summary", { jobTitle, profile });
      setSkillsSummary(text);
    } catch (e) {
      setGenError(`Skills summary failed: ${e.message}`);
    } finally {
      setSummaryLoading(false);
    }
  }

  function updateResponseText(id, text) {
    setRequirements((prev) => prev.map((r) => (r.id === id ? { ...r, response: text } : r)));
  }

  function buildExportBlob() {
    return requirements
      .map((r) => `Requirement ${r.number}: ${r.text}\n\n${r.response}\n`)
      .join("\n---\n\n") + `\n\nSpecial Skills & Associations\n\n${skillsSummary}`;
  }

  function copyAll() {
    navigator.clipboard.writeText(buildExportBlob());
  }

  function downloadText() {
    const url = URL.createObjectURL(new Blob([buildExportBlob()], { type: "text/plain" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${jobTitle.replace(/\s+/g, "_") || "application"}_responses.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const navy = "#16233F", red = "#B5122E", paper = "#F6F3EC", ink = "#262A33", brass = "#A6824C", line = "#D9D3C4";
  const serif = "'Iowan Old Style', 'Palatino Linotype', Georgia, serif";

  return (
    <div style={{ background: paper, minHeight: "100vh", color: ink, fontFamily: "'Inter', system-ui, sans-serif" }}>
      <header style={{ background: navy, borderBottom: `4px solid ${red}` }} className="px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div style={{ background: red, color: "white", fontFamily: serif }} className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0">★</div>
            <div>
              <div style={{ fontFamily: serif, color: "white" }} className="text-lg leading-tight tracking-wide">{APP_NAME}</div>
              <div style={{ color: "#AEB8CC" }} className="text-xs tracking-wide uppercase">{APP_TAGLINE}</div>
            </div>
          </div>
          <div style={{ color: "#AEB8CC" }} className="hidden sm:flex text-xs font-mono gap-1">
            {STEPS.map((s, i) => (
              <span key={s} style={{ color: i <= stepIndex ? brass : "#4A5A80" }}>{i > 0 && "— "}{s}</span>
            ))}
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-10">
        {genError && step !== "requirements" && step !== "title" && (
          <div className="mb-6 p-3 rounded text-sm flex items-center gap-2" style={{ background: "#FBEAEA", color: red }}>
            <AlertTriangle size={14} /> {genError}
          </div>
        )}

        {step === "title" && (
          <Section title="Look up the position" eyebrow="Step 1" serif={serif} navy={navy}>
            <p className="mb-5 text-sm" style={{ color: "#5B5F68" }}>
              Enter the exact job title from the eCareer posting. We'll check our library first;
              if it's not there, paste the qualifications straight from the posting.
            </p>
            <div className="flex gap-2">
              <input
                value={jobTitle}
                onChange={(e) => { setJobTitle(e.target.value); setSearched(false); }}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                placeholder="e.g. Manager, Post Office Operations"
                className="flex-1 px-4 py-3 rounded border outline-none"
                style={{ borderColor: line, background: "white" }}
              />
              <button onClick={handleSearch} className="px-5 py-3 rounded font-medium text-white flex items-center gap-2" style={{ background: navy }}>
                <Search size={16} /> Search
              </button>
            </div>
            <div className="mt-2 text-xs" style={{ color: "#8A8D94" }}>
              Try "Manager, Post Office Operations" or "Supervisor, Customer Services" for the demo library.
            </div>

            {searched && libraryMatch && (
              <div className="mt-6 p-4 rounded border" style={{ borderColor: line, background: "white" }}>
                <div className="flex items-center gap-2 text-sm font-medium" style={{ color: navy }}>
                  <CheckCircle2 size={16} /> Found in library: {libraryMatch.title}
                </div>
                <button onClick={() => setStep("requirements")} className="mt-3 px-4 py-2 rounded text-white text-sm flex items-center gap-2" style={{ background: red }}>
                  Review requirements <ArrowRight size={14} />
                </button>
              </div>
            )}

            {searched && !libraryMatch && (
              <div className="mt-6 p-4 rounded border" style={{ borderColor: line, background: "white" }}>
                <div className="flex items-center gap-2 text-sm font-medium mb-2" style={{ color: red }}>
                  <AlertTriangle size={16} /> Not in our library yet
                </div>
                <p className="text-sm mb-3" style={{ color: "#5B5F68" }}>
                  Paste the "Qualifications" section from the eCareer posting below.
                </p>
                <textarea
                  value={pastedText}
                  onChange={(e) => setPastedText(e.target.value)}
                  rows={7}
                  placeholder="Paste the qualifications/requirements text here..."
                  className="w-full px-3 py-2 rounded border text-sm outline-none"
                  style={{ borderColor: line }}
                />
                {genError && <div className="mt-2 text-sm" style={{ color: red }}>{genError}</div>}
                <button
                  onClick={handleExtractFromPaste}
                  disabled={extracting || !pastedText.trim()}
                  className="mt-3 px-4 py-2 rounded text-white text-sm flex items-center gap-2 disabled:opacity-50"
                  style={{ background: navy }}
                >
                  {extracting ? <RefreshCw size={14} className="animate-spin" /> : <Sparkles size={14} />}
                  {extracting ? "Extracting requirements…" : "Extract requirements"}
                </button>
              </div>
            )}
          </Section>
        )}

        {step === "requirements" && (
          <Section title="Confirm the requirements" eyebrow="Step 2" serif={serif} navy={navy}>
            <p className="mb-5 text-sm" style={{ color: "#5B5F68" }}>
              {requirements.length} requirement{requirements.length !== 1 ? "s" : ""} for{" "}
              <strong>{jobTitle || libraryMatch?.title}</strong>. Edit any wording that doesn't match the posting exactly.
            </p>
            <div className="space-y-3">
              {requirements.map((r) => (
                <div key={r.id} className="p-4 rounded border flex gap-3" style={{ borderColor: line, background: "white" }}>
                  <Seal number={r.number} color={brass} />
                  <textarea
                    value={r.text}
                    onChange={(e) => setRequirements((prev) => prev.map((x) => (x.id === r.id ? { ...x, text: e.target.value } : x)))}
                    rows={2}
                    className="flex-1 text-sm outline-none resize-none bg-transparent"
                  />
                  <button
                    onClick={() => setRequirements((prev) => prev.filter((x) => x.id !== r.id).map((x, i) => ({ ...x, number: i + 1 })))}
                    className="shrink-0" style={{ color: "#B0B4BB" }}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
              <button
                onClick={() => setRequirements((prev) => [...prev, { id: `req-${Date.now()}`, number: prev.length + 1, text: "", budget: Math.floor(TOTAL_CHARACTER_BUDGET / (prev.length + 1)), response: "", generating: false }])}
                className="flex items-center gap-2 text-sm px-3 py-2 rounded border" style={{ borderColor: line, color: navy }}
              >
                <Plus size={14} /> Add requirement manually
              </button>
            </div>
            <StepNav onBack={() => setStep("title")} onNext={() => setStep("payment")} nextLabel="Continue to payment"
              nextDisabled={requirements.length === 0 || requirements.some((r) => !r.text.trim())} />
          </Section>
        )}

        {step === "payment" && (
          <Section title="Unlock this application" eyebrow="Step 3" serif={serif} navy={navy}>
            <div className="p-6 rounded border max-w-md" style={{ borderColor: line, background: "white" }}>
              <div className="flex items-center justify-between mb-4">
                <div style={{ fontFamily: serif }} className="text-lg">{jobTitle || libraryMatch?.title}</div>
                <div style={{ color: navy }} className="text-2xl font-semibold flex items-center">
                  <DollarSign size={20} />{(FLAT_FEE_CENTS / 100).toFixed(0)}
                </div>
              </div>
              <ul className="text-sm mb-4 space-y-1" style={{ color: "#5B5F68" }}>
                <li>· AI-drafted STAR responses for all {requirements.length} requirements</li>
                <li>· Unlimited edits and regenerations for this application</li>
                <li>· Special Skills & Associations summary</li>
                <li>· Export to text / Word</li>
              </ul>
              <input
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                placeholder="Promo code (optional)"
                className="w-full mb-3 px-3 py-2 rounded border text-sm outline-none"
                style={{ borderColor: line }}
              />
              <button
                onClick={handlePay}
                disabled={paying}
                className="w-full py-3 rounded text-white font-medium flex items-center justify-center gap-2 disabled:opacity-60"
                style={{ background: red }}
              >
                {paying ? <RefreshCw size={16} className="animate-spin" /> : <DollarSign size={16} />}
                {paying ? "Redirecting to checkout…" : `Pay $${(FLAT_FEE_CENTS / 100).toFixed(0)}`}
              </button>
              <div className="mt-3 text-xs" style={{ color: "#8A8D94" }}>
                Real Stripe Checkout — requires STRIPE_SECRET_KEY in .env.local. See README.
              </div>
            </div>
            <StepNav onBack={() => setStep("requirements")} />
          </Section>
        )}

        {step === "intake" && (
          <Section title="Tell us about your background" eyebrow="Step 4" serif={serif} navy={navy}>
            <p className="mb-5 text-sm" style={{ color: "#5B5F68" }}>
              This is reused for future applications. Only fill in what's relevant — the AI only draws on what you provide here.
            </p>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Current position / grade" value={profile.currentPosition} onChange={(v) => setProfile((p) => ({ ...p, currentPosition: v }))} placeholder="e.g. EAS-20, Manager, Operation Programs Support" />
              <Field label="Years in current role" value={profile.yearsInRole} onChange={(v) => setProfile((p) => ({ ...p, yearsInRole: v }))} placeholder="e.g. 4 years" />
              <Field label="Key projects / initiatives" value={profile.projects} textarea onChange={(v) => setProfile((p) => ({ ...p, projects: v }))} placeholder="e.g. Led the Internal Variance Workstream; Cap-Metro Lean Challenge" />
              <Field label="Programs / tools / systems used" value={profile.programsTools} textarea onChange={(v) => setProfile((p) => ({ ...p, programsTools: v }))} placeholder="e.g. AMS, FDB, DSALS, RADAR/PDAT, Kanban, Gemba walks" />
              <Field label="Measurable outcomes" value={profile.outcomes} textarea onChange={(v) => setProfile((p) => ({ ...p, outcomes: v }))} placeholder="e.g. Reduced workhour variance by X%" />
              <Field label="Leadership / supervisory scope" value={profile.leadershipScope} textarea onChange={(v) => setProfile((p) => ({ ...p, leadershipScope: v }))} placeholder="e.g. Supervised 12 employees, F1/F2 budget authority" />
              <Field label="Training / certifications" value={profile.training} textarea onChange={(v) => setProfile((p) => ({ ...p, training: v }))} placeholder="e.g. S&DC Core Team member" />
            </div>
            <StepNav onBack={() => setStep("payment")} onNext={generateAll} nextLabel="Generate my responses" nextIcon={Sparkles} />
          </Section>
        )}

        {step === "generate" && (
          <Section title="Generating your responses…" eyebrow="Step 5" serif={serif} navy={navy}>
            <div className="space-y-3">
              {requirements.map((r) => (
                <div key={r.id} className="p-4 rounded border flex items-center gap-3" style={{ borderColor: line, background: "white" }}>
                  <Seal number={r.number} color={r.response ? brass : "#D9D3C4"} />
                  <div className="flex-1 text-sm" style={{ color: "#5B5F68" }}>{r.text}</div>
                  {r.generating && <RefreshCw size={16} className="animate-spin" style={{ color: navy }} />}
                  {r.response && !r.generating && <CheckCircle2 size={16} style={{ color: navy }} />}
                </div>
              ))}
            </div>
          </Section>
        )}

        {step === "review" && (
          <Section title="Review & export" eyebrow="Step 6" serif={serif} navy={navy}>
            <div className="mb-6 p-4 rounded border flex items-center justify-between" style={{ borderColor: overBudget ? red : line, background: "white" }}>
              <div className="text-sm" style={{ color: "#5B5F68" }}>Total across all requirements</div>
              <div className="font-mono text-lg" style={{ color: overBudget ? red : navy }}>
                {totalUsed.toLocaleString()} / {TOTAL_CHARACTER_BUDGET.toLocaleString()}
              </div>
            </div>

            <div className="space-y-4">
              {requirements.map((r) => (
                <div key={r.id} className="p-5 rounded border" style={{ borderColor: line, background: "white" }}>
                  <div className="flex items-start gap-3 mb-3">
                    <Seal number={r.number} color={brass} />
                    <div className="flex-1">
                      <div className="text-sm font-medium mb-1" style={{ color: navy }}>Requirement {r.number}</div>
                      <div className="text-xs" style={{ color: "#8A8D94" }}>{r.text}</div>
                    </div>
                    <button onClick={() => generateOne(r)} disabled={r.generating} className="shrink-0 text-xs px-3 py-1.5 rounded border flex items-center gap-1" style={{ borderColor: line, color: navy }}>
                      <RefreshCw size={12} className={r.generating ? "animate-spin" : ""} /> Regenerate
                    </button>
                  </div>
                  <textarea
                    value={r.response}
                    onChange={(e) => updateResponseText(r.id, e.target.value)}
                    rows={6}
                    className="w-full text-sm p-3 rounded outline-none"
                    style={{ background: paper, fontFamily: "'Iowan Old Style', Georgia, serif" }}
                  />
                  <div className="mt-1 text-right text-xs font-mono" style={{ color: r.response.length > r.budget ? red : "#8A8D94" }}>
                    {r.response.length.toLocaleString()} chars (budget {r.budget.toLocaleString()})
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 p-5 rounded border" style={{ borderColor: line, background: "white" }}>
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-medium" style={{ color: navy }}>Special Skills & Associations</div>
                <button onClick={generateSkillsSummary} disabled={summaryLoading} className="text-xs px-3 py-1.5 rounded border flex items-center gap-1" style={{ borderColor: line, color: navy }}>
                  <RefreshCw size={12} className={summaryLoading ? "animate-spin" : ""} /> Regenerate
                </button>
              </div>
              <textarea
                value={skillsSummary}
                onChange={(e) => setSkillsSummary(e.target.value)}
                rows={4}
                className="w-full text-sm p-3 rounded outline-none"
                style={{ background: paper, fontFamily: "'Iowan Old Style', Georgia, serif" }}
              />
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={copyAll} className="px-4 py-2.5 rounded border text-sm flex items-center gap-2" style={{ borderColor: line, color: navy }}>
                <Copy size={14} /> Copy all
              </button>
              <button onClick={downloadText} className="px-4 py-2.5 rounded text-white text-sm flex items-center gap-2" style={{ background: navy }}>
                <Download size={14} /> Download .txt
              </button>
            </div>
          </Section>
        )}
      </main>
    </div>
  );
}

function Section({ title, eyebrow, serif, navy, children }) {
  return (
    <div>
      <div className="text-xs tracking-widest uppercase mb-1" style={{ color: "#A6824C" }}>{eyebrow}</div>
      <h1 style={{ fontFamily: serif, color: navy }} className="text-2xl mb-6">{title}</h1>
      {children}
    </div>
  );
}

function Seal({ number, color }) {
  return (
    <div className="shrink-0 w-9 h-9 rounded-full border-2 flex items-center justify-center font-mono text-xs font-bold" style={{ borderColor: color, color }}>
      {number}
    </div>
  );
}

function Field({ label, value, onChange, placeholder, textarea }) {
  return (
    <div>
      <label className="block text-xs font-medium mb-1" style={{ color: "#5B5F68" }}>{label}</label>
      {textarea ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={3}
          className="w-full px-3 py-2 rounded border text-sm outline-none" style={{ borderColor: "#D9D3C4" }} />
      ) : (
        <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
          className="w-full px-3 py-2 rounded border text-sm outline-none" style={{ borderColor: "#D9D3C4" }} />
      )}
    </div>
  );
}

function StepNav({ onBack, onNext, nextLabel, nextDisabled, nextIcon: NextIcon }) {
  return (
    <div className="mt-8 flex items-center justify-between">
      <button onClick={onBack} className="text-sm flex items-center gap-1" style={{ color: "#5B5F68" }}>
        <ArrowLeft size={14} /> Back
      </button>
      {onNext && (
        <button onClick={onNext} disabled={nextDisabled} className="px-5 py-2.5 rounded text-white text-sm font-medium flex items-center gap-2 disabled:opacity-50" style={{ background: "#B5122E" }}>
          {NextIcon ? <NextIcon size={14} /> : null}{nextLabel} <ArrowRight size={14} />
        </button>
      )}
    </div>
  );
}
